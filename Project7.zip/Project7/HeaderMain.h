#pragma once

#include<vector>

#include<fstream>
#include<sstream>
#include<algorithm>
#include<iterator>
#include<iostream>
#include<string>

#include<memory>
#include"base.h"
#include "chocolate.h"
#include"marshmellow.h"
#include"lollypop.h"

#include"sweets1.h"
